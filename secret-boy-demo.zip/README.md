# Secret Boy Demo (GitHub Pages Ready)

This is a simple **mobile-friendly demo** of the Secret Boy game UI.

## How to Deploy on GitHub Pages

1. Create a new repository on GitHub (e.g., `secret-boy-demo`).
2. Upload the file `index.html` into the repository root.
3. Go to **Settings > Pages** in the repository.
4. Under "Source" select **Branch: main** and Folder: `/root`.
5. Save → Your demo will be live at:

   ```
   https://<your-username>.github.io/secret-boy-demo/index.html
   ```

## Features

- Login modal simulation
- Wallet balance deposit & withdraw
- Play game simulation with wins counter
- Auto demo runner (shows flow automatically)

Works on both **Desktop** and **Mobile browsers**.
